//
//  ToDoCell.swift
//  ToDoList
//
//  Created by Adrian on 9/12/18.
//  Copyright © 2018 Adrian. All rights reserved.
//

import UIKit

@objc protocol ToDoCellDelegate: class {
    func checkmarkButtonTapped(sender: ToDoCell)
}

class ToDoCell: UITableViewCell {
    
    var delegate: ToDoCellDelegate?
    
    @IBOutlet weak var isCompleteButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    
    
    
    
    
    @IBAction func checkmarkButtonTapped(_ sender: UIButton) {
        delegate?.checkmarkButtonTapped(sender: self)
    }
    
}
