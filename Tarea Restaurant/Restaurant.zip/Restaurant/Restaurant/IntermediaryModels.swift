//
//  IntermediaryModels.swift
//  Restaurant
//
//  Created by Adrian on 9/13/18.
//  Copyright © 2018 Adrian. All rights reserved.
//

import Foundation

struct Categories: Codable {
    let categories: [String]
}

struct PreparationTime: Codable {
    let prepTime: Int
    
    enum CodingKeys: String, CodingKey{
        case prepTime = "preparation_time"
    }
}
