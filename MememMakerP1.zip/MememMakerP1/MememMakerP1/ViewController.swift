//
//  ViewController.swift
//  MememMakerP1
//
//  Created by Adrian on 8/16/18.
//  Copyright © 2018 Adrian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var topSegment: UISegmentedControl!
    @IBOutlet weak var topLabel: UILabel!
    @IBOutlet weak var botLabel: UILabel!
    @IBOutlet weak var botSegment: UISegmentedControl!
    
    
    var topChoices = [CaptionChoice]()
    var botChoices = [CaptionChoice]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        //Los segmentos trabajan con indices, empezando desde el cero
        
        
        let whatsCoolChoide = CaptionChoice(emoji: "😎", caption: "You know what's cool?")
        let madChoice = CaptionChoice(emoji: "🤬", caption: "you know what makes me mad?")
        let loveChoice = CaptionChoice(emoji: "😍", caption: "You know what makes me love?😘")
        
        topChoices = [whatsCoolChoide, madChoice, loveChoice]
        
        //Poder remover las opciones por default
        topSegment.removeAllSegments()
        for choice in topChoices {
            topSegment.insertSegment(withTitle: choice.emoji, at: topChoices.count, animated: false)
        }
        topSegment.selectedSegmentIndex = 0
        
        //Segmento inferior
        
        let monkeyChoice = CaptionChoice(emoji: "🙈", caption: "Than the monkeys are very shy")
        let dogChoice = CaptionChoice(emoji: "🐕", caption: "Dogs are the best friends")
        let dolphinChoice = CaptionChoice(emoji: "🐬", caption: "Dolphins can attack in group")
        
        botChoices = [monkeyChoice, dogChoice, dolphinChoice]
        botSegment.removeAllSegments()
        for choice in botChoices {
            botSegment.insertSegment(withTitle: choice.emoji, at: botChoices.count, animated: false)
        }
        botSegment.selectedSegmentIndex = 0
        updatingLabels()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    func updatingLabels(){
        let topIndex = topSegment.selectedSegmentIndex
        let botIndex = botSegment.selectedSegmentIndex
        
        let topChoice = topChoices[topIndex]
        let botChoice = botChoices[botIndex]
        
        topLabel.text = topChoice.caption
        botLabel.text = botChoice.caption
    }
    
    
    @IBAction func choiceSelected(_ sender: Any) {
        updatingLabels()

    }

}

