//
//  CaptionChoice.swift
//  MememMakerP1
//
//  Created by Adrian on 8/16/18.
//  Copyright © 2018 Adrian. All rights reserved.
//

import Foundation


struct CaptionChoice{
    let emoji: String
    let caption: String
}
