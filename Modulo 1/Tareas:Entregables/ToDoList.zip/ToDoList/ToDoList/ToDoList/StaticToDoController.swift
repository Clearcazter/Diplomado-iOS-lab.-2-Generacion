//
//  StaticToDoController.swift
//  ToDoList
//
//  Created by Adrian on 9/6/18.
//  Copyright © 2018 Adrian. All rights reserved.
//

import UIKit

class StaticToDoController: UITableViewController{
    
    @IBOutlet weak var titleTextField: UITextField!
    @IBOutlet weak var isCompleteButton: UIButton!
    @IBOutlet weak var dueDateLabel: UILabel!
    @IBOutlet weak var dueDate: UIDatePicker!
    @IBOutlet weak var notesTextField: UITextView!
    
    
    @IBOutlet weak var saveButton: UIButton!
    
    var isPickerHidden = true
    var todo: ToDo?
    
    
    ///////////////////////////////
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if let todo = todo {
            navigationItem.title = "To-Do"
            titleTextField.text = todo.title
            isCompleteButton.isSelected = todo.isComplete
            dueDate.date = todo.dueDate
            notesTextField.text = todo.notes
            
        }else {
            dueDate.date = Date().addingTimeInterval(24*60*60)
        }
        
        //dueDate.date = Date().addingTimeInterval(24*60*60)
        updateDueDateLabel(date: dueDate.date)
        updateSaveButtonState()
    }
    
    override func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        let normalCellHeight = CGFloat(44)
        let largeCellHeight = CGFloat(200)
        
        switch (indexPath) {
        case [0,1]: //Date Cell
            return isPickerHidden ? normalCellHeight : largeCellHeight
        case [0,2]: //Notes Cell
            return largeCellHeight
        default:
            return normalCellHeight
        }
    }
    
    override func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch (indexPath) {
        case [0,1]:
            isPickerHidden = !isPickerHidden
            tableView.deselectRow(at: indexPath, animated: true)
            dueDateLabel.textColor = isPickerHidden ? .black : tableView.tintColor
            tableView.beginUpdates()
            tableView.endUpdates()
        default:
            break
        }
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        guard segue.identifier == "saveUnwind" else { return }
        
        let title = titleTextField.text!
        let isComplete = isCompleteButton.isSelected
        let dueDate1 = dueDate.date
        let notes = notesTextField.text!
        
        todo = ToDo(title: title, isComplete: isComplete, dueDate: dueDate1, notes: notes)
    }

    func updateSaveButtonState(){
        let text = titleTextField.text ?? ""
        saveButton.isEnabled = !text.isEmpty
    }
    
    func updateDueDateLabel(date: Date){
        dueDateLabel.text = ToDo.dueDateFormatter.string(from: date)
    }
    
    
    
    
    
    
    @IBAction func textEditingChange(_ sender: UITextField) {
        updateSaveButtonState()
    }
    @IBAction func returnPressed(_ sender: UITextField) {
        titleTextField.resignFirstResponder()
    }
    @IBAction func isCompleteButtonTapped(_ sender: UIButton) {
        isCompleteButton.isSelected = !isCompleteButton.isSelected
    }
    
    @IBAction func datePickerChange(_ sender: UIDatePicker) {
        updateDueDateLabel(date: dueDate.date)
    }
    
    
    
    
}
