//
//  ToDoCell.swift
//  ToDoList
//
//  Created by Adrian on 9/6/18.
//  Copyright © 2018 Adrian. All rights reserved.
//

import UIKit

@objc protocol ToDoCellDelegate: class {
    func checkmarkTapped(sender: ToDoCell)
}

class ToDoCell: UITableViewCell {
    
    var delegate :ToDoCellDelegate?
    
    @IBOutlet weak var isCompleteButton: UIButton!
    @IBOutlet weak var titleLabel: UILabel!
    
    
    @IBAction func completeButtonTaped(_ sender: UIButton) {
        delegate?.checkmarkTapped(sender: self)
    }
    
    
    
    
}
