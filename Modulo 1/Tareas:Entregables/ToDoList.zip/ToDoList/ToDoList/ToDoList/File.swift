//
//  File.swift
//  ToDoList
//
//  Created by Adrian on 9/5/18.
//  Copyright © 2018 Adrian. All rights reserved.
//

import UIKit

struct ToDo: Codable{
    let title: String
    let isComplete: Bool
    let dueDate:Date
    let notes: String
   // let image: UIImage
    
    
    static func loadToDos() ->  [ToDo]?{
        guard let codedToDos = try? Data(contentsOf: ArchiveURL)
            else {return nil}
        let propertyListDecoder = PropertyListDecoder()
        return try? propertyListDecoder.decode(Array<ToDo>.self, from: codedToDos)
        return loadsSampleToDos()
    }
    
    static func loadsSampleToDos() -> [ToDo]{
        let toDo1 = ToDo(title: "Lista To Do(Diplomado)", isComplete: false, dueDate: Date(), notes: "Terminar la aplicacion de la lista")
        let toDo2 = ToDo(title: "Aplicacion de Restaurant Diplomado", isComplete: false, dueDate: Date(), notes: "Terminar la aplicacion del restaurante del Diplomado")
        let toDo3 = ToDo(title: "Comprobante de Diplomado", isComplete: false, dueDate: Date(), notes: "Imprimir y firmar el comprobante del pago del diplomado")
        let toDo4 = ToDo(title: "Foto de Generación", isComplete: false, dueDate: Date(), notes: "Llama ry pedir la foto de generacion")
        let toDo5 = ToDo(title: "Estudiar CAD", isComplete: false, dueDate: Date(), notes: "Estudiar lo de CAD y un poco de sintaxis de C")
        
        return [toDo1, toDo2, toDo3, toDo4, toDo5]
    }
    //Formato para el tiempo limite
    static let dueDateFormatter: DateFormatter = {
        let formatter = DateFormatter()
        //en display lo mas corto que sea posible.
        formatter.dateStyle = .short
        formatter.timeStyle = .short
        return formatter
    }()
    
     static let DocumentDirectory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask).first!
    
    static let ArchiveURL = DocumentDirectory.appendingPathComponent("todos").appendingPathExtension("plist")
    
    static func saveToDos(_ todos: [ToDo]){
        
//        let propertyListEncoder = PropertyListEncoder()
//        let codedToDos = try? propertyListEncoder.encode(todos)
//        try? codedToDos?.write(to: ArchiveURL, options: .noFileProtection)
    }
    
}
